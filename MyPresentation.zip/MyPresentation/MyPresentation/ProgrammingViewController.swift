//
//  ProgrammingViewController.swift
//  MyPresentation
//
//  Created by Neto on 21/08/22.
//

import Charts
import UIKit

class ProgrammingViewController: UIViewController, ChartViewDelegate
{
    var barChart = BarChartView()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        barChart.delegate = self
    }
    
    override func viewDidLayoutSubviews()
    {
        super.viewDidLayoutSubviews()
        
        barChart.frame = CGRect(x: 0, y: 0,
                                width: self.view.frame.size.width,
                                height: self.view.frame.size.width)
        
        barChart.center = view.center
        
        view.addSubview(barChart)
        
        let set = BarChartDataSet(entries: [
            BarChartDataEntry(x: 1,
                              y: 0.90),
            BarChartDataEntry(x: 2,
                              y: 0.90),
            BarChartDataEntry(x: 3,
                              y: 0.90),
            BarChartDataEntry(x: 4,
                              y: 0.82),
            BarChartDataEntry(x: 5,
                              y: 0.75),
            BarChartDataEntry(x: 6,
                              y: 0.70),
            BarChartDataEntry(x: 7,
                              y: 0.40),
            BarChartDataEntry(x: 8,
                              y: 0.25),
            BarChartDataEntry(x: 9,
                              y: 0.12),
            BarChartDataEntry(x: 10,
                              y: 0.5),
            
        ], label: "Programming Languages")
        
        set.colors = ChartColorTemplates.joyful()
        
        let data = BarChartData(dataSet: set)
        
        barChart.data = data
        
        let labels = ["C++", "Bash", "Python", "C", "Matlab", "C#", "Java", "Haskell", "R", "JavaScript"]
        
        barChart.xAxis.valueFormatter = IndexAxisValueFormatter(values: labels)
        
        barChart.xAxis.granularity = 1
        
    }
        
}
